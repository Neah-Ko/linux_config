#!/usr/bin/env python3
# /// script
# requires-python = ">=3.10"
# dependencies = ["databricks-sql-connector>=4"]
# ///
"""dbx — compact Databricks query helper for agentic use.

Connection comes from ~/.databrickscfg (profile 'dev' by default). The default
warehouse reads esxp_dev, esxp_dev_pr and esxp_uat (same workspace/metastore).
esxp_prd is a separate workspace: use --profile prd (auto-selects its warehouse).
Fully qualify tables as catalog.schema.table.

Usage:
  dbx "SELECT ..."                      raw SQL (';'-separated multi-statement)
  dbx schemas <catalog>                 SHOW SCHEMAS
  dbx tables  <catalog.schema> [like]   SHOW TABLES (+ substring filter)
  dbx desc    <catalog.schema.table>    columns + types
  dbx sample  <catalog.schema.table> [N]
  dbx count   <catalog.schema.table> ["where clause"]
  dbx pr                                print resolved PR number

PR-scoped schemas are named pr<N>_<schema>. The token {pr} in any SQL/table arg
expands to the resolved PR number:
  dbx --pr auto count 'esxp_dev.pr{pr}_gold_analytics.coef' "measurement_value IS NULL"

Global flags (anywhere): --profile P --warehouse ID --pr N|auto --repo DIR
  --json --csv --limit N --no-limit --max-col N
Env: DBX_WAREHOUSE, DBX_PR, DBX_REPO
"""
from __future__ import annotations

import configparser
import json
import os
import re
import subprocess
import sys
from pathlib import Path

from databricks import sql

DEFAULT_WAREHOUSE = "0632bd3c72a82b45"  # dev workspace: reads esxp_dev, esxp_dev_pr, esxp_uat
PROFILE_WAREHOUSE = {"prd": "69bc4af4cdee445f"}  # esxp_prd is a separate workspace
KNOWN_CMDS = {"schemas", "tables", "desc", "sample", "count", "pr", "sql"}


# ---- argument parsing (hand-rolled so bare SQL stays ergonomic) -------------
FLAGS_WITH_VALUE = {"--profile", "--warehouse", "--pr", "--repo", "--limit", "--max-col"}
FLAGS_BOOL = {"--json", "--csv", "--no-limit"}


def parse_args(argv: list[str]) -> tuple[dict, list[str]]:
    opts: dict = {}
    pos: list[str] = []
    i = 0
    while i < len(argv):
        a = argv[i]
        if a in FLAGS_WITH_VALUE:
            opts[a.lstrip("-")] = argv[i + 1]
            i += 2
        elif a in FLAGS_BOOL:
            opts[a.lstrip("-")] = True
            i += 1
        else:
            pos.append(a)
            i += 1
    return opts, pos


# ---- connection -------------------------------------------------------------
def connect(profile: str, warehouse: str):
    cfg = configparser.ConfigParser()
    read = cfg.read(Path.home() / ".databrickscfg")
    if not read or profile not in cfg:
        sys.exit(f"dbx: profile '{profile}' not found in ~/.databrickscfg")
    host = cfg[profile]["host"].replace("https://", "").rstrip("/")
    token = cfg[profile]["token"]
    wh = warehouse if warehouse.startswith("/sql/") else f"/sql/1.0/warehouses/{warehouse}"
    return sql.connect(server_hostname=host, http_path=wh, access_token=token)


# ---- PR resolution ----------------------------------------------------------
_PR_CACHE: dict = {}


def resolve_pr(pr_arg: str | None, repo: str) -> str:
    if pr_arg and pr_arg != "auto":
        return str(pr_arg)
    if os.environ.get("DBX_PR"):
        return os.environ["DBX_PR"]
    if "n" in _PR_CACHE:
        return _PR_CACHE["n"]
    n = _gh_pr(repo) or _branch_pr(repo)
    if not n:
        sys.exit("dbx: could not resolve PR number; pass --pr N or set DBX_PR")
    _PR_CACHE["n"] = n
    return n


def _gh_pr(repo: str) -> str | None:
    try:
        r = subprocess.run(
            ["gh", "pr", "view", "--json", "number", "--jq", ".number"],
            cwd=repo, capture_output=True, text=True, timeout=20,
        )
        s = r.stdout.strip()
        return s if r.returncode == 0 and s.isdigit() else None
    except (OSError, subprocess.SubprocessError):
        return None


def _branch_pr(repo: str) -> str | None:
    try:
        r = subprocess.run(
            ["git", "rev-parse", "--abbrev-ref", "HEAD"],
            cwd=repo, capture_output=True, text=True, timeout=10,
        )
        m = re.search(r"pr[-_/]?(\d+)", r.stdout, re.I)
        return m.group(1) if m else None
    except (OSError, subprocess.SubprocessError):
        return None


def subst_pr(text: str, opts: dict) -> str:
    if "{pr}" not in text:
        return text
    repo = opts.get("repo") or os.environ.get("DBX_REPO") or os.getcwd()
    return text.replace("{pr}", resolve_pr(opts.get("pr"), repo))


# ---- SQL building -----------------------------------------------------------
def split_statements(sql_text: str) -> list[str]:
    # Split on ';' while ignoring separators inside '...', "...", or `...`.
    stmts: list[str] = []
    buf: list[str] = []
    quote: str | None = None
    i, n = 0, len(sql_text)
    while i < n:
        c = sql_text[i]
        if quote:
            buf.append(c)
            if c == quote:
                if i + 1 < n and sql_text[i + 1] == quote:  # escaped '' "" ``
                    buf.append(sql_text[i + 1])
                    i += 2
                    continue
                quote = None
        elif c in "'\"`":
            quote = c
            buf.append(c)
        elif c == ";":
            stmts.append("".join(buf))
            buf = []
        else:
            buf.append(c)
        i += 1
    stmts.append("".join(buf))
    return [s.strip() for s in stmts if s.strip()]


def maybe_limit(stmt: str, opts: dict) -> str:
    if opts.get("no-limit"):
        return stmt
    if not re.match(r"(?is)^\s*select\b", stmt):
        return stmt
    if re.search(r"(?is)\blimit\s+\d+\s*$", stmt):
        return stmt
    return f"{stmt} LIMIT {opts.get('limit', 100)}"


# ---- output -----------------------------------------------------------------
def emit(cols: list[str], rows: list, opts: dict) -> None:
    if cols is None:
        return
    if opts.get("json"):
        for r in rows:
            print(json.dumps(dict(zip(cols, [_j(v) for v in r])), default=str))
    elif opts.get("csv"):
        print(",".join(cols))
        for r in rows:
            print(",".join(_csv(v) for v in r))
    else:
        _table(cols, rows, int(opts.get("max-col", 60)))
    print(f"({len(rows)} row{'s' if len(rows) != 1 else ''})", file=sys.stderr)


def _j(v):
    return v


def _csv(v) -> str:
    s = "" if v is None else str(v)
    return f'"{s}"' if any(c in s for c in ',"\n') else s


def _table(cols: list[str], rows: list, max_col: int) -> None:
    def cell(v) -> str:
        s = "" if v is None else str(v)
        return s if len(s) <= max_col else s[: max_col - 1] + "\u2026"

    data = [[cell(v) for v in r] for r in rows]
    widths = [len(c) for c in cols]
    for r in data:
        for i, v in enumerate(r):
            widths[i] = max(widths[i], len(v))
    print(" | ".join(c.ljust(widths[i]) for i, c in enumerate(cols)))
    print("-+-".join("-" * w for w in widths))
    for r in data:
        print(" | ".join(v.ljust(widths[i]) for i, v in enumerate(r)))


# ---- command dispatch -------------------------------------------------------
def build_sql(pos: list[str], opts: dict) -> str | None:
    cmd = pos[0] if pos and pos[0] in KNOWN_CMDS else None
    rest = pos[1:] if cmd else pos

    if cmd == "pr":
        repo = opts.get("repo") or os.environ.get("DBX_REPO") or os.getcwd()
        print(resolve_pr(opts.get("pr"), repo))
        return None
    if cmd == "schemas":
        return f"SHOW SCHEMAS IN {rest[0]}"
    if cmd == "tables":
        return f"SHOW TABLES IN {rest[0]}"  # like-filter applied post-query
    if cmd == "desc":
        return f"DESCRIBE TABLE {rest[0]}"
    if cmd == "sample":
        n = rest[1] if len(rest) > 1 else "10"
        return f"SELECT * FROM {rest[0]} LIMIT {n}"
    if cmd == "count":
        where = f" WHERE {rest[1]}" if len(rest) > 1 else ""
        return f"SELECT COUNT(*) AS n FROM {rest[0]}{where}"
    # bare SQL (optionally after 'sql')
    return " ".join(rest)


def main() -> None:
    opts, pos = parse_args(sys.argv[1:])
    if not pos:
        sys.exit(__doc__)

    cmd = pos[0] if pos[0] in KNOWN_CMDS else None
    raw = build_sql(pos, opts)
    if raw is None:  # handled inline (pr)
        return

    raw = subst_pr(raw, opts)
    like = pos[2].lower() if cmd == "tables" and len(pos) > 2 else None
    profile = opts.get("profile", "dev")
    warehouse = (opts.get("warehouse") or os.environ.get("DBX_WAREHOUSE")
                 or PROFILE_WAREHOUSE.get(profile) or DEFAULT_WAREHOUSE)

    stmts = split_statements(raw)
    if not stmts:
        sys.exit("dbx: empty query")

    with connect(profile, warehouse) as conn:
        with conn.cursor() as cur:
            for stmt in stmts:
                if cmd not in {"tables", "desc", "sample", "count", "schemas"}:
                    stmt = maybe_limit(stmt, opts)
                cur.execute(stmt)
                if cur.description is None:
                    continue
                cols = [d[0] for d in cur.description]
                rows = cur.fetchall()
                if like is not None:
                    rows = [r for r in rows if any(like in str(v).lower() for v in r)]
                emit(cols, list(rows), opts)


if __name__ == "__main__":
    main()
