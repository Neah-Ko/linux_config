# Core table reference (`esxp_dev` / `esxp_uat` / `esxp_prd` / `esxp_dev_pr`)

Load on demand. Columns are identical across environments; PR ephemeral schemas live in `esxp_dev_pr` as `pr<N>_<schema>` (clones of the `esxp_dev` base). For live/PR schemas always prefer `dbx desc <catalog.schema.table>` — this file is a convenience snapshot, not authoritative.

## gold_analytics.execution_context
Analytics runs and their POV hierarchy.

| Column | Type | Notes |
|---|---|---|
| run_id | string | run key |
| root_pov_id / parent_pov_id / child_pov_id | string | POV hierarchy ids |
| root_pov_urn / parent_pov_urn / child_pov_urn | string | POV hierarchy urns |
| virtual_asset_id | string | |
| pov_index | integer | index in hierarchy |
| pov_relation_name | string | relation between POVs |
| _creation_date | timestamp | |

## gold_analytics.execution_context_input
Inputs consumed by a run.

| Column | Type | Notes |
|---|---|---|
| run_id | string | |
| root_pov_id / parent_pov_id / child_pov_id | string | |
| input_type | string | e.g. measurement, config |
| measurement_urn | string | |
| remote_id | string | device id |
| value_item_id | string | topic |
| value | string/double | |

## gold_analytics.execution_context_output
Outputs produced by a run.

| Column | Type |
|---|---|
| run_id | string |
| root_pov_id / parent_pov_id / child_pov_id | string |
| measurement_urn | string |

## gold_analytics.coef
Computed coefficients per POV/measurement (UPS Global Score).

| Column | Type | Notes |
|---|---|---|
| run_id | string | |
| pov_id | string | |
| measurement_urn | string | |
| measurement_value | double | coefficient (0..1); may be NULL |
| last_compute_date | timestamp | |
| measurement_timestamp | timestamp | source measure ts |

## gold_core.normalized_cleaned_measures
Main time-series table (cleaned/normalized device measures).

| Column | Type | Notes |
|---|---|---|
| id | string | row id |
| remote_id | string | device id |
| value_item_id | string | topic/channel |
| value_numeric | double | |
| value_string | string | |
| timestamp | timestamp | |
| quality | string | quality flag |
| _annotations | struct | processing metadata |

`_annotations` fields: publication_timestamp, kafka_timestamp, raw_timestamp, silver_timestamp, bronze_timestamp, gold_timestamp, message_id, comment, source, value_date, applied_scaling_factor.
